function [radians] = deg2rad(deg)
%deg: input degrees
%returns the conversion from degrees to radians
radians = (deg*pi)/180.0;