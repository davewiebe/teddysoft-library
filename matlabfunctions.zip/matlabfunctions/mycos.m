function [y,T] = mycos(f0, dur, fs)
%My sinusiod function
%f0 : frequency 
%dur : duration in seconds
%fs : sampling rate
w = 2*pi*f0;

%T = [0:dur/fs:dur];
T = [0:dur/fs:3/200];

y = cos(w*T);


