function [y,T,A] = ADSR(atime,dtime,rtime,sustainValue,f0,dur,fs)
%
NumOfAttackSamples = fs*atime;
NumOfDecaySamples = fs*dtime;
NumOfReleaseSamples = fs*rtime;
T = [0:dur/fs:dur];
A = [ [0:1/NumOfAttackSamples:1] [1:-0.2/NumOfDecaySamples:sustainValue] [sustainValue.*ones( 1,(length(T)-(NumOfAttackSamples+1) - (NumOfDecaySamples+1) -(NumOfReleaseSamples+1) ) )] [sustainValue:(-1*sustainValue)/NumOfReleaseSamples:0] ];
z = cos(2*pi*f0*T);
y = A.*z;
