function [radians] = deg2rad(deg)
radians = (deg*pi)/180.0;